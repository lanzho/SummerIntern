package com.example.demo.domin;

public class User {
    private String EmployeeId;
    private String OtherName;
    private String RealName;
    private String NickName;
    private String ContractName;
    private String PONumber;
    private int BusCenter;
    private String WBS;
    private String Location;


    public User() {
        super();
    }

    public User(String employeeId, String otherName, String realName, String nickName, String contractName, String PONumber, int busCenter, String WBS, String location) {
        this.EmployeeId = employeeId;
        this.OtherName = otherName;
        this.RealName = realName;
        this.NickName = nickName;
        this.ContractName = contractName;
        this.PONumber = PONumber;
        this.BusCenter = busCenter;
        this.WBS = WBS;
        this.Location = location;
    }

    public String getEmployeeId() {
        return EmployeeId;
    }

    public void setEmployeeId(String employeeId) {
        EmployeeId = employeeId;
    }

    public String getOtherName() {
        return OtherName;
    }

    public void setOtherName(String otherName) {
        OtherName = otherName;
    }

    public String getRealName() {
        return RealName;
    }

    public void setRealName(String realName) {
        RealName = realName;
    }

    public String getNickName() {
        return NickName;
    }

    public void setNickName(String nickName) {
        NickName = nickName;
    }

    public String getContractName() {
        return ContractName;
    }

    public void setContractName(String contractName) {
        ContractName = contractName;
    }

    public String getPONumber() {
        return PONumber;
    }

    public void setPONumber(String PONumber) {
        this.PONumber = PONumber;
    }

    public int getBusCenter() {
        return BusCenter;
    }

    public void setBusCenter(int busCenter) {
        BusCenter = busCenter;
    }

    public String getWBS() {
        return WBS;
    }

    public void setWBS(String WBS) {
        this.WBS = WBS;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }
}
