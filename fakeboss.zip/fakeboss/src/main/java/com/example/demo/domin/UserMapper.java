package com.example.demo.domin;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import java.util.List;

@Mapper
public interface UserMapper {
    @Select("insert into user values(user)")
    void insert(User user);


    @Select("select * from user")
    List<User> selectAll();
}
