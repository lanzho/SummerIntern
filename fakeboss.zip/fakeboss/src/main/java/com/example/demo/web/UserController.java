package com.example.demo.web;

import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
@RequestMapping("/login/*")
public class UserController {
    @Autowired
    private UserService userService;

    //添加
    @RequestMapping("/log")
    public String logg() {
        userService.listAll();
        return "loginsuccess";
    }


    //登录成功页面
    @RequestMapping("/loginsuccess")
    public String logsuc() {
        userService.creat();
        return "loginsuccess";
    }
}
