package com.example.demo.web;


import com.example.demo.domin.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;


@Controller
@RequestMapping("/login/*")
public class UserController {
    @Autowired
    private UserService userService;

    //登录
    @RequestMapping("/log")
    public String logg() {
        return "loginsuccess";
    }


    //登录成功页面
    @RequestMapping("/loginsuccess")
    public String logsuc() {
        return "loginsuccess";
    }
}
